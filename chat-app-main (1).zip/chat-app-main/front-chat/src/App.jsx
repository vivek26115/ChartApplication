import toast from 'react-hot-toast'
import './App.css'
import JoinCreateChat from './component/JoinCreateChat'

function App() {

  return (
    <div>
      <JoinCreateChat />
    </div>
  )
}

export default App
